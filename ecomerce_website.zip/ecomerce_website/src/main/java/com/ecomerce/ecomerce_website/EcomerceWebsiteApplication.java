package com.ecomerce.ecomerce_website;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcomerceWebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcomerceWebsiteApplication.class, args);
	}

}
