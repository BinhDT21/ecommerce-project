package com.ecomerce.ecomerce_website;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcomerceWebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
